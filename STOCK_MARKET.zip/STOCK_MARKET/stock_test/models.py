from django.db import models
# Create your models here.
class User_Query(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=80)
    query_date = models.DateField(null=True)
    subject_line = models.CharField(max_length=400)
    greeting = models.CharField(max_length=300)
    comment = models.TextField(max_length=800)
   
    class Meta:
        db_table = 'User_Query' 

class Stock_Market_model(models.Model):
    comany_name = models.CharField(max_length=80)
    prices = models.CharField(max_length=80)
    persentes = models.CharField(max_length=90)
    more_detail = models.CharField(max_length=400)
    def __str__(self):
        return str(self.pk)