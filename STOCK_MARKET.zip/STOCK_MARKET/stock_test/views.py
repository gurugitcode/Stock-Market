from django.http import request
from django.shortcuts import render,HttpResponseRedirect
from  django.views import View
from django.contrib.auth.models import User, Group
from .forms import User_create_form,LoginForm,Form_User_Query
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash
from .models import User_Query,Stock_Market_model
from django.http import JsonResponse
from django.views.generic import View,TemplateView
# Create your views here.

# Main page
class Home_page(View):
    templates_name = 'Stockpage_html/Home_page.html'
    # templates_name='Stockpage_html/Log_in.html'
    def get(self,request):
        fm=LoginForm()
        return render(request,self.templates_name,{"login_user":fm})
    
    def post(self,request):
        if request.method =='POST':
            fm = LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    group = Group.objects.get(name='Client')
                    users = group.user_set.all()
                    messages.success(request,'Login in Successfuly')
                    return HttpResponseRedirect('/data/Stock_Market_Page')
        else:
            fm=LoginForm()
        return render(request,self.templates_name,{'login_user':fm})

    # def get(self,request):
    #     return render (request,self.templates_name)
# Stock_Market_Page

class Stock_Market_Page(View):
    templates_name = 'Stockpage_html/SM_page.html'
    def get(self,request):
        if request.user.is_authenticated:
            return render (request,self.templates_name)
        else:
            return HttpResponseRedirect('/logout_user/login')

 

# User Create Aoccunt
class User_create_account(View):
    templates_name = 'Stockpage_html/Sign_up.html'
    def get(self,request):
        fm_data = User_create_form()
        return render(request,self.templates_name,{"form":fm_data})

    def post(self,request):
        if request.method =='POST':
            fm_data = User_create_form(request.POST)
            if fm_data.is_valid():
                messages.success(request,'Congratulations You have become authot')
                user=fm_data.save()
                group = Group.objects.get(name='Author')
                user.groups.add(group)
                fm_data =User_create_form()
        else:
            fm_data =User_create_form()
        return render(request,self.templates_name,{"form":fm_data}) 

# define User Login 
class Login_User(View):
    templates_name='Stockpage_html/Log_in.html'
    def get(self,request):
        fm=LoginForm()
        return render(request,self.templates_name,{"login_user":fm})
    
    def post(self,request):
        if request.method =='POST':
            fm = LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    group = Group.objects.get(name='Client')
                    users = group.user_set.all()
                    messages.success(request,'Login in Successfuly')
                    return HttpResponseRedirect('/data/Stock_Market_Page')
        else:
            fm=LoginForm()
        return render(request,self.templates_name,{'login_user':fm})

# Logout_User
class User_logout(View):
    def get(self,request):
        if request.user.is_authenticated:
            logout(request)
            return HttpResponseRedirect('/logout_user/login')
        else:
            return HttpResponseRedirect('/logout_user/login')

class Stok_Market(View):
    def get(self,request):
        if request.user.is_authenticated:
            return render(request,'Stockpage_html/stock_market.html')
        else:
            return HttpResponseRedirect('/logout_user/login')

#User Feedback 
class User_Feedback(View):
    template_name = 'Stockpage_html/Feedback.html'
    def get(self,request):
        if request.user.is_authenticated:
            fm = Form_User_Query()
            return render(request,self.template_name,{'form':fm})
        else:
            return HttpResponseRedirect('/logout_user/login')
    def post(self,request):
        if request.user.is_authenticated:
            fm = Form_User_Query(request.POST)
            if fm.is_valid():
                # user = request.user
                nm = fm.cleaned_data['name']
                em = fm.cleaned_data['email']
                qd = fm.cleaned_data['query_date']
                sl = fm.cleaned_data['subject_line']
                gt = fm.cleaned_data['greeting']
                cm = fm.cleaned_data['comment']
                rec = User_Query(name=nm,email=em,query_date=qd,subject_line=sl,greeting=gt,comment=cm)
                rec.save()
                messages.success(request,'Successfully Your Post uploded.')
                fm = Form_User_Query()
                return render(request,self.template_name,{'form':fm})
        else:
            return HttpResponseRedirect('/logout_user/login')      


class MainView(TemplateView):
    template_name = 'Stockpage_html/main.html'

class PostJsonListView(View):
    def get(self,*args,**kwargs):
        print(kwargs)
        upper=kwargs.get('num_posts')
        lower=upper-3
        posts=list(Stock_Market_model.objects.values()[lower:upper])
        posts_size=len(Stock_Market_model.objects.all())
        size=True if upper >= posts_size else False
        return JsonResponse({'data':posts,'max':size},safe=False)
# class popup(View):
#     template_name = 'Stockpage_html/loginpopup.html'
#     def get(self,request):
#         return render(request,self.template_name)
