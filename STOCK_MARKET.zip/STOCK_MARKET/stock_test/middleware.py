from django.shortcuts import HttpResponse,render
# class based Hook middleware 
