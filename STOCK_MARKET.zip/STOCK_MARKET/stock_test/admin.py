from django.contrib import admin
from .models import User_Query,Stock_Market_model
from django.contrib import admin
import csv
from django.http import HttpResponse
from django.db.models import F

#User Query admin panel page downlode in csv file

def userquery(modeladmin, request, queryset):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Uquerydata.csv"'
    writer = csv.writer(response)
    writer.writerow(['Name', 'Email', 'Query_Date', 'Subject_Line', 'Greeting','Comment'])
    User_Query = queryset.values_list('name', 'email', 'query_date', 'subject_line', 'greeting','comment')
    for data in User_Query:
        writer.writerow(data)
    return response
userquery.short_description = 'Export to csv'

# User Query admin page 
 
class UserQueryAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'query_date', 'subject_line', 'greeting','comment']
    actions = ['userquery_data', userquery]
 
admin.site.register(User_Query, UserQueryAdmin)

admin.site.register(Stock_Market_model)