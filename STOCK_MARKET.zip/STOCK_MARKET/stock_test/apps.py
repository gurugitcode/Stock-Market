from django.apps import AppConfig


class StockTestConfig(AppConfig):
    name = 'stock_test'
    def ready(self):
        import stock_test.signals


