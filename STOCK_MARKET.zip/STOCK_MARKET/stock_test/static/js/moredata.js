console.log('hello world')

const postsBox = document.getElementById('posts')
console.log(postsBox)
const spinnerBox = document.getElementById('spinner-box')
const loadBtn = document.getElementById('load-btn')
const loadBox = document.getElementById('loading-box')

let visible = 6
const handleGetData = () => {
    $.ajax({
        type: 'GET',
        url: `/post/post/${visible}`,
        success: function(response) {
            // console.log(response.max)
            max_size = response.max
            const data = response.data
            spinnerBox.classList.remove('not-visible')
            setTimeout(() => {
                spinnerBox.classList.add('not-visible')
                data.map(post => {
                    console.log(post.id)
                    postsBox.innerHTML += `<div class="card p-3 mt-3">
                    ${post.comany_name}
                    &ensp;&ensp;&ensp;&ensp;&ensp;
                    ${post.prices}
                    &ensp;&ensp;&ensp;&ensp;&ensp;
                    ${post.persentes}
                    &ensp;&ensp;&ensp;&ensp;&ensp;
                    ${post.more_detail}
                    </div>`
                })
            }, 500)

            if (max_size) {
                console.log('done')
                loadBox.innerHTML = "<h4> No more Stock market data</h4>"
            }

        },
        error: function(errer) {
            console.log(error)
        }
    })

}
handleGetData()
loadBtn.addEventListener('click', () => {
    visible += 3
    handleGetData()
})