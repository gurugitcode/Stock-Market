from django.contrib import admin
from django.urls import path
from django.urls import include, path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.Home_page.as_view(),name='HOME'),
    path('Stock_Market_Page/',views.Stock_Market_Page.as_view(),name='Stock_Market'),
    path('create_account/',views.User_create_account.as_view(),name='create_account'),
    path('login/',views.Login_User.as_view(),name='login'),
    path('log/',views.User_logout.as_view(),name="logout"),
    path('details/',views.Stok_Market.as_view(),name="stock_market_graph"),
    path('decs/',views.User_Feedback.as_view(),name="User_Feedback"),
    path('main/',views.MainView.as_view(),name="main"),
    path('post/<int:num_posts>/',views.PostJsonListView.as_view(),name="post"),
   

]
