from django.contrib.auth.models import Group
from django.contrib.auth.models import User

def post_save_user_signal_handler(sender, instance, created, **kwargs):
    if created:
        # instance.is_superuser = False   
        instance.is_staff = False
        group = Group.objects.get(name='clients')
        instance.groups.add(group)
        instance.save()
