"""Stock_Market URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.urls import include, path
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('stock_test.urls')),
    path('Stack_m/',include('stock_test.urls')),
    path('create_account/',include('stock_test.urls')),
    path('login/',include('stock_test.urls')),
    path('logout_user/',include('stock_test.urls')),
    path('stock/',include('stock_test.urls')),
    path('data/',include('stock_test.urls')),
    path('main/',include('stock_test.urls')),
    path('post/',include('stock_test.urls')),
   
]
